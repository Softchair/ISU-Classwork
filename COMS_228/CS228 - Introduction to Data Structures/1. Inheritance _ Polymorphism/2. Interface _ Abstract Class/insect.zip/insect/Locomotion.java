package insect;

public interface Locomotion 
{
	void move(); 
}
