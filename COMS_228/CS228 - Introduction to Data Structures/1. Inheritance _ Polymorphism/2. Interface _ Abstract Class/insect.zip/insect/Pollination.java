package insect;

public interface Pollination 
{
	boolean pollinate(); 
}
