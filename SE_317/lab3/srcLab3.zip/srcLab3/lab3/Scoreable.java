package lab3;

@FunctionalInterface
public interface Scoreable {
	int getScore();

}
